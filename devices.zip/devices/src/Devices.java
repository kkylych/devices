class Devices {
    private String type;
    private double price;
    private double weight;

    public Devices(String type, double price, double weight) {
        this.type = type;
        this.price = price;
        this.weight = weight;
    }

    public String getType() {
        return type;
    }

    public double getPrise() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
}




// double screenSize = 3020;
//int cameraResolution = 24;

